CREATE TRIGGER update_status_after_copies_change
AFTER UPDATE ON Books
FOR EACH ROW
BEGIN
    UPDATE Books
    SET Status = 'OUT OF STOCK'
    WHERE BookID = NEW.BookID AND NEW.Copies = 0;

    UPDATE Books
    SET status = 'AVAILABLE'
    WHERE id = NEW.id AND NEW.copies > 0;
END;

